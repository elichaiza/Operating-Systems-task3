#ifndef REACTOR_H
#define REACTOR_H

#include <vector>
#include <stack>
#include <functional>
using namespace std;
using reactorFunc = std::function<void(int)>;

class Reactor {
private:
    int max_fd;
    fd_set read_set;
    unordered_map<int, reactorFunc> fd_func;

public:
    Reactor();
    ~Reactor();
    // starts new reactor and returns pointer to it
    void *startReactor();

    // adds fd to Reactor (for reading) ; returns 0 on success.
    int addFdToReactor(int fd, reactorFunc func);

    // removes fd from reactor
    int removeFdFromReactor(int fd);

    // stops reactor
    int stopReactor();
};

#endif // REACTOR_H
