
#ifndef PROACTOR_HPP
#define PROACTOR_HPP

#include <pthread.h>

// Define a function pointer type for the proactor thread function
typedef void* (*proactorFunc)(int sockfd);

// Starts a new proactor thread and returns the thread id
pthread_t startProactor(int sockfd, proactorFunc threadFunc);

// Stops the proactor thread by its thread id
int stopProactor(pthread_t tid);

#endif // PROACTOR_HPP
