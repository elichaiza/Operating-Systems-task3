#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <cstring>
#include <list>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <poll.h>
#include <functional>
#include "reactor.hpp"
#include "Vector_List.hpp"
#include <unordered_map>

#define PORT "9034"


using namespace std;


Graph::Graph(int n) {
    this->n = n;
    adj = vector<list<int>>(n);
}

Graph Graph::Newgraph(int n,int m,int client_fd) {
    Graph aa(n);
    int v;
    int w;
    for(size_t i=0;i<m;i++) {
        cout<<"Write the two vertices where you want to create an arc: " << endl;
        cin>>v>>w;
        aa.Newedge(v,w);
    }
    return aa;

}

void Graph::Newedge(int v, int w) {
    adj[v - 1].push_back(w - 1); // הוספת קשת מ-v ל-w (מינוס 1 כדי להתאים לאינדקסים של 0)
    cout<<"the edge between "<<v <<"end "<<w << "adding successfully"<<endl;
}
void Graph:: Removeedge(int i,int j) {
    auto it = find(adj[i].begin(), adj[i].end(), j);

    // אם המספר נמצא, הסר אותו
    if (it != adj[i].end()) {
        adj[i].erase(it);
        cout << "המספר " << j << " הוסר מהרשימה במקום " << i << "." << endl;
    } else {
        cout << "המספר " << j << " לא נמצא ברשימה במקום " << i << "." << endl;
    }
}

void Graph::fillOrder(int v, vector<bool>& visited, stack<int> &Stack) {
    visited[v] = true;

    for (int i : adj[v])
        if (visited[i]==false) {
            fillOrder(i, visited, Stack);
        }
    Stack.push(v);
}

void Graph::DFSUtil(int v, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v + 1); // להחזיר לקודקודים את האינדקס המקורי

    for (int i : adj[v])
        if (visited[i]==false)
            DFSUtil(i, visited, component);
}

Graph Graph::getTranspose() {
    Graph aa(n);
    for (int v = 0; v < n; v++)
        for (int i : adj[v])
            aa.adj[i].push_back(v);
    return aa;
}

 void Graph::Kosaraju(){
    stack<int> Stack;
    vector<bool> visited(n, false);
    for (int i = 0; i < n; i++){
        if (!visited[i]){
            fillOrder(i, visited, Stack);
        }
    }

    Graph gr = getTranspose();
    fill(visited.begin(), visited.end(), false);
    if(Stack.size()==0) {
  cout<<"the stack is empty!!!!!!!!!"<<endl;    }

    while (!Stack.empty()) {
        int v = Stack.top();
        Stack.pop();
        if (!visited[v]) {
            vector<int> component;
            gr.DFSUtil(v, visited, component);
            sort(component.begin(), component.end());
            for (int i : component)
                cout << i << " ";
            cout << endl;
        }
    }
  }

void print_Kosaraju(const vector<list<int>>& adj , int client_fd) {
    // Print the strongly connected components
    for (const auto& component : adj) {
        string result;
        for (int node : component) {
            result += to_string(node + 1) + " ";  // Adjust for 1-based indexing in output
        }
        result += "\n";
        send(client_fd, result.c_str(), result.size(), 0);
    }
}

Reactor reactor;

void HandleCommand(const string& command, int client_fd,Graph &aa) {
    cout << "Received command: " << command << endl;
    try {
        if (command.substr(0, 8) == "Newgraph"){
            cout << "Processing Newgraph command" << endl;
        size_t pos = 9;
        size_t next_space = command.find(" ", pos);
        int n = stoi(command.substr(pos, next_space - pos));
        pos = next_space + 1;
        int m = stoi(command.substr(pos));
        aa=aa.Newgraph(n, m, client_fd);
    }
         else if (command.substr(0, 8) == "Kosaraju") {
            cout << "Processing Kosaraju command" << endl;
             aa.Kosaraju();
             // print_Kosaraju(a->adj, client_fd);

        } else if (command.substr(0, 7) == "Newedge") {
            cout << "Processing Newedge command" << endl;
            size_t pos = 8;
            size_t next_space = command.find(" ", pos);
            int u = stoi(command.substr(pos, next_space - pos));
            pos = next_space + 1;
            int v = stoi(command.substr(pos));
            aa.Newedge(u,v);
            send(client_fd, "Edge added\n", 11, 0);

        } else if (command.substr(0, 10) == "Removeedge") {
            cout << "Processing Removeedge command" << endl;
            size_t pos = 11;
            size_t next_space = command.find(" ", pos);
            int u = stoi(command.substr(pos, next_space - pos));
            pos = next_space + 1;
            int v = stoi(command.substr(pos));
            aa.Removeedge(u,v);
            send(client_fd, "Edge removed\n", 13, 0);

        } else {
            cout << "Unknown command: " << command << endl;
            send(client_fd, "Unknown command\n", 16, 0);
        }
    } catch (const exception& e) {
        cerr << "Error handling command: " << e.what() << endl;
        send(client_fd, "Error processing command\n", 25, 0);
    }
}







// Get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

// Return a listening socket
int get_listener_socket(){
    int listener;     // Listening socket descriptor
    int yes=1;        // For setsockopt() SO_REUSEADDR, below
    int rv;

    struct addrinfo hints, *ai, *p;

    // Get us a socket and bind it
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;  // we dont have a preference to ipv4 or ipv6
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    if ((rv = getaddrinfo(NULL, PORT, &hints, &ai)) != 0) {
        fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
        exit(1);
    }

    for(p = ai; p != NULL; p = p->ai_next) {
        listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (listener < 0) {
            continue;
        }

        // Lose the pesky "address already in use" error message
        setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

        if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) {
            close(listener);
            continue;
        }

        break;
    }

    freeaddrinfo(ai); // All done with this

    // If we got here, it means we didn't get bound
    if (p == NULL) {
        return -1;
    }

    // Listen
    if (listen(listener, 10) == -1) {
        return -1;
    }

    return listener;
}

//Add a new file descriptor to the set
void add_to_pfds(vector<pollfd>& pfds, int newfd) {
    pfds.push_back({newfd, POLLIN, 0});
}

// Remove an index from the set
void del_from_pfds(vector<pollfd>& pfds, int i) {
    pfds.erase(pfds.begin() + i);
}







int main(){
    Graph aa(0);
    vector<list<int>> adj;

   int listener;     // Listening socket descriptor

    int newfd;        // Newly accept()ed socket descriptor
    struct sockaddr_storage remoteaddr{}; // Client address
    socklen_t addrlen;

    char buf[256];    // Buffer for client data

    char remoteIP[INET6_ADDRSTRLEN];


    // Start off with room for 5 connections
    // (We'll realloc as necessary)
    vector<pollfd> pfds;
    pfds.reserve(5);

    // Set up and get a listening socket
    listener = get_listener_socket();

    if (listener == -1) {
        cerr << "error getting listening socket" << endl;
        exit(1);
    }
    else(cout<<"listening socket succeeded"<<endl);

    // Add the listener to set
    pfds.push_back({listener, POLLIN, 0});
    cout<<"Add the listener to set"<<endl;


    auto commandHandler = [](int client_fd) {
        char buf[256];
        int nbytes = recv(client_fd, buf, sizeof(buf), 0);

        if (nbytes <= 0) {
            if (nbytes == 0) {
                cout << "pollserver: socket " << client_fd << " hung up" << endl;
            } else {
                perror("recv");
            }

            close(client_fd);
            // Optionally remove from pfds and Reactor, if necessary
        } else {
            string command(buf, nbytes);
            Graph abc(0);
            HandleCommand(command, client_fd,abc);
        }
    };

    // Reactor setup
    Reactor reactor;
    reactor.startReactor();

    // Main loop
    for (;;) {
        int poll_count = poll(pfds.data(), pfds.size(), -1);
        if (poll_count == -1) {
            perror("poll");
            exit(1);
        }
        for (size_t i = 0; i < pfds.size(); i++) {
            if (pfds[i].revents & POLLIN) {
                if (pfds[i].fd == listener) {
                    addrlen = sizeof remoteaddr;
                    newfd = accept(listener, (struct sockaddr*)&remoteaddr, &addrlen);

                    if (newfd == -1) {
                        perror("accept");
                    } else {
                        add_to_pfds(pfds, newfd);

                        cout << "pollserver: new connection from "
                             << inet_ntop(remoteaddr.ss_family,
                                          get_in_addr((struct sockaddr*)&remoteaddr),
                                          remoteIP, INET6_ADDRSTRLEN)
                             << " on socket " << newfd << endl;

                        // Add new connection to Reactor
                        reactor.addFdToReactor(newfd, commandHandler);
                    }
                } else {
                    int sender_fd = pfds[i].fd;
                    int nbytes = recv(sender_fd, buf, sizeof(buf), 0);

                    if (nbytes <= 0) {
                        if (nbytes == 0) {
                            cout << "pollserver: socket " << sender_fd << " hung up" << endl;
                        } else {
                            perror("recv");
                        }

                        close(sender_fd);
                        del_from_pfds(pfds, i);

                        // Remove from Reactor
                        reactor.removeFdFromReactor(sender_fd);
                    } else {
                        // Process received command
                        string command(buf, nbytes);
                        HandleCommand(command, sender_fd,aa);
                    }
                }
            }
        }
    }

    return 0;
}

