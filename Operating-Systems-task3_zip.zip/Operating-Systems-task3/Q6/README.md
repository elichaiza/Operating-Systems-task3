nc localhost 9034   פקודה לחיבור שכותבים בclient ושולח לserver
גם כאן אנחנו כותבים את אותם 