#include "reactor.hpp"
#include <iostream>
#include <unistd.h>
#include <cstring>
#include <unordered_map>

Reactor::Reactor() : max_fd(-1) {
    FD_ZERO(&read_set);
}

Reactor::~Reactor() {
    stopReactor();
}

void *Reactor::startReactor() {
    cout << "Reactor started\n"<< endl;;
    return this;
}

int Reactor::addFdToReactor(int fd, reactorFunc func) {
    if(fd<0) {
        cout<< "error in the file descriptors "<<endl;
        return -1;
    }

    if(FD_ISSET(fd,&read_set)!=0) {
        cout<<"the file descriptors already exists"<<endl;
        return -1;
    }
    if(max_fd>fd) {
        this->max_fd=fd;
    }
    FD_SET(fd, &read_set);

    std::cout << "Added file descriptors " << fd << " to reactor \n";
    return 0; // Success
}
int Reactor::removeFdFromReactor(int fd) {
    if(FD_ISSET(fd,&read_set)!=0) {
        cout<<"the file descriptor arent exists on the reactor"<<endl;
        return -1;
    }
    else {
        FD_CLR(fd,&read_set);
        cout<<"the file descriptors removing successfully from the reactor."<<endl;
        return 0;
    }
}

    int Reactor::stopReactor(){
        fd_func.clear();

        std::cout << "Reactor stopped\n"<<endl;

        return 0; // Success

}