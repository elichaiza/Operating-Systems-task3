#include <iostream>
#include <vector>
#include <list>
#include <stack>
#include <algorithm>

#include "Vector_List.hpp"



Graph::Graph(int n) {
    this->n = n;
    adj = vector<list<int>>(n);
}
Graph Graph::Newgraph(int n,int m) {
    Graph a(n);
    int v;
    int w;
    for(size_t i=0;i<m;i++) {
        cout<<"Write the two vertices where you want to create an arc: " << endl;
        cin>>v>>w;
        a.Newedge(v,w);
    }
    return a;

}

void Graph::Newedge(int v, int w) {
    adj[v - 1].push_back(w - 1); // הוספת קשת מ-v ל-w (מינוס 1 כדי להתאים לאינדקסים של 0)
    cout<<"the edge between "<<v <<"end "<<w << "adding uccessfully"<<endl;
}
void Graph:: Removeedge(int i,int j) {
    auto it = find(adj[i].begin(), adj[i].end(), j);

    // אם המספר נמצא, הסר אותו
    if (it != adj[i].end()) {
        adj[i].erase(it);
        cout << "המספר " << j << " הוסר מהרשימה במקום " << i << "." << endl;
    } else {
        cout << "המספר " << j << " לא נמצא ברשימה במקום " << i << "." << endl;
    }

    }
void Graph::fillOrder(int v, vector<bool>& visited, stack<int>& Stack) {
    visited[v] = true;

    for (int i : adj[v])
        if (!visited[i])
            fillOrder(i, visited, Stack);

    Stack.push(v);
}

void Graph::DFSUtil(int v, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v + 1); // להחזיר לקודקודים את האינדקס המקורי

    for (int i : adj[v])
        if (!visited[i])
            DFSUtil(i, visited, component);
}

Graph Graph::getTranspose() {
    Graph g(n);
    for (int v = 0; v < n; v++)
        for (int i : adj[v])
            g.adj[i].push_back(v);
    return g;
}

void Graph::Kosaraju() {
    stack<int> Stack;

    vector<bool> visited(n, false);

    for (int i = 0; i < n; i++)
        if (!visited[i])
            fillOrder(i, visited, Stack);

    Graph gr = getTranspose();

    fill(visited.begin(), visited.end(), false);

    while (!Stack.empty()) {
        int v = Stack.top();
        Stack.pop();

        if (!visited[v]) {
            vector<int> component;
            gr.DFSUtil(v, visited, component);

            sort(component.begin(), component.end());
            for (int i : component)
                cout << i << " ";
            cout << endl;
        }
    }
}

int main() {
    int n;
    int m;
    cin>>n>>m;
    Graph a(n);
    a=a.Newgraph(n,m);
    a.Kosaraju();
    a.Removeedge(1,2);
    a.Kosaraju();
    return 0;
}