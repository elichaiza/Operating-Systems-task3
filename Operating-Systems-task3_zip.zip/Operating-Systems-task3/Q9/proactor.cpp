
#include <pthread.h>
#include <unistd.h>
#include <iostream>
#include "proactor.hpp"

#include "../Q2/Matrix.hpp"

void* proactorThreadWrapper(void* param) {
    auto* threadData = static_cast<std::pair<int, proactorFunc>*>(param);
    int socket_fd = threadData->first;
    proactorFunc threadFunction = threadData->second;
    delete threadData; // Clean up dynamically allocated memory
    return threadFunction(socket_fd);
}

pthread_t startProactor(int client_fd, proactorFunc  threadFunc) {
    pthread_t thread;
    auto* arg = new std::pair<int, proactorFunc>(client_fd,  threadFunc);
    if (pthread_create(&thread, nullptr, proactorThreadWrapper, arg)!= 0) {
        std::cerr << "Failed to create proactor thread" << std::endl;
        return 0;
    }
    return thread;
}

// Function to stop the proactor thread
int stopProactor(pthread_t tid) {
    // stop the thread
    if (pthread_cancel(tid) != 0) {
        std::cerr << "Error stopping proactor thread" << std::endl;
        return -1;
    }
    if (pthread_join(tid, NULL) != 0) {
        std::cerr << "Error joining proactor thread" << std::endl;
        return -1;
    }
    return 0;
}
