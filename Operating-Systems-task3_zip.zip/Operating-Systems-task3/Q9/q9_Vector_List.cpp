#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <cstring>
#include <list>
#include <map>
#include <mutex>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <poll.h>
#include <thread>
#include "proactor.hpp"
#include "Vector_List.hpp"

#define PORT "9034"
using namespace std;
struct ClientInfo {
    int client_fd;
    pthread_t thread_id;
};
mutex listOfTheGraph;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexCondition = PTHREAD_MUTEX_INITIALIZER;
bool mostGraphConnected = false;
bool wasMajority = false;
bool notLongerMajority = false;


//Graph* aa=new Graph(0);
vector<list<int>> adj;

Graph::Graph(int n) {
    this->n = n;
    adj = vector<list<int>>(n);
}
Graph Graph::Newgraph(int n,int m,int client_fd) {
    Graph aa(n);
    int v;
    int w;
    for(size_t i=0;i<m;i++) {
        char buf[256];
        int two_edge_of_client = recv(client_fd, buf, sizeof buf, 0);
        if (two_edge_of_client <= 0) {
            cerr << "Error receiving graph input from client" << endl;
            break;
        }
        buf[two_edge_of_client] = '\0';  // Null-terminate the string
        sscanf(buf, "%d %d", &v, &w);
        aa.Newedge(v,w);
    }
    cout<<"We got all the edges successfully "<<endl;
    return aa;
}

void Graph::Newedge(int v, int w) {
    adj[v - 1].push_back(w - 1); // הוספת קשת מ-v ל-w (מינוס 1 כדי להתאים לאינדקסים של 0)
    cout<<"the edge between "<<v <<"end "<<w << "adding successfully"<<endl;
}
void Graph:: Removeedge(int i,int j) {
    auto it = find(adj[i].begin(), adj[i].end(), j);

    // אם המספר נמצא, הסר אותו
    if (it != adj[i].end()) {
        adj[i].erase(it);
        cout << "המספר " << j << " הוסר מהרשימה במקום " << i << "." << endl;
    } else {
        cout << "המספר " << j << " לא נמצא ברשימה במקום " << i << "." << endl;
    }

    }
void Graph::fillOrder(int v, vector<bool>& visited, stack<int> &Stack) {
    visited[v] = true;

    for (int i : adj[v])
        if (visited[i]==false) {
            fillOrder(i, visited, Stack);
        }
    Stack.push(v);
}

void Graph::DFSUtil(int v, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v + 1); // להחזיר לקודקודים את האינדקס המקורי

    for (int i : adj[v])
        if (visited[i]==false)
            DFSUtil(i, visited, component);
}

Graph Graph::getTranspose() {
    Graph aa(n);
    for (int v = 0; v < n; v++)
        for (int i : adj[v])
            aa.adj[i].push_back(v);
    return aa;
}

 void Graph::Kosaraju(){
    stack<int> Stack;
    vector<bool> visited(n, false);
    for (int i = 0; i < n; i++){
        if (!visited[i]){
            fillOrder(i, visited, Stack);
        }
    }

    Graph gr = getTranspose();
    fill(visited.begin(), visited.end(), false);
    if(Stack.size()==0) {
  cout<<"the stack is empty!!!!!!!!!"<<endl;    }

    while (!Stack.empty()) {
        int v = Stack.top();
        Stack.pop();
        if (!visited[v]) {
            vector<int> component;
            gr.DFSUtil(v, visited, component);
            sort(component.begin(), component.end());
            for (int i : component)
                cout << i << " ";
            cout << endl;
        }
    }
  }
void printStronglyConnectedComponents(const vector<list<int>>& adj, int client_fd) {
    bool foundMajority = false;

    pthread_mutex_lock(&mutexCondition);
    for (int i = 0; i < adj.size(); ++i) {
        if (adj[i].size() > adj.size() / 2) {
            mostGraphConnected = true;
            wasMajority = true;
            foundMajority = true;
            pthread_cond_signal(&cond);
            break;
        }
    }
    std::cout << "foundMajority: " << foundMajority << std::endl;
    std::cout << "wasMajority: " << wasMajority << std::endl;

    if(foundMajority == false && wasMajority == true){
        notLongerMajority = true;
        pthread_cond_signal(&cond);
    }

    pthread_mutex_unlock(&mutexCondition);






    // Print the strongly connected components
    for (const auto& component : adj) {
        string result;

        for (int node : component) {
            result += to_string(node + 1) + " ";  // Adjust for 1-based indexing in output
        }
        result += "\n";
        send(client_fd, result.c_str(), result.size(), 0);
    }

    pthread_mutex_unlock(&mutexCondition);
}
void print_Kosaraju(const vector<list<int>>& adj , int client_fd) {
    // Print the strongly connected components
    for (const auto& component : adj) {
        string result;
        for (int node : component) {
            result += to_string(node + 1) + " ";  // Adjust for 1-based indexing in output
        }
        result += "\n";
        send(client_fd, result.c_str(), result.size(), 0);
    }
}
void HandleCommand(const string& command, int client_fd,Graph &aa) {
    cout << "Received command: " << command << endl;
    try {
        if (command.substr(0, 8) == "Newgraph"){
            cout << "Processing Newgraph command" << endl;
        size_t pos = 9;
        size_t next_space = command.find(" ", pos);
        int n = stoi(command.substr(pos, next_space - pos));
        pos = next_space + 1;
        int m = stoi(command.substr(pos));
            lock_guard<mutex> lock(listOfTheGraph); // Lock the list .
        aa=aa.Newgraph(n, m, client_fd);
    }
         else if (command.substr(0, 8) == "Kosaraju") {
            cout << "Processing Kosaraju command" << endl;
             lock_guard<mutex> lock(listOfTheGraph); // Lock the list .
             aa.Kosaraju();
              printStronglyConnectedComponents(adj, client_fd);

        } else if (command.substr(0, 7) == "Newedge") {
            cout << "Processing Newedge command" << endl;
            size_t pos = 8;
            size_t next_space = command.find(" ", pos);
            int u = stoi(command.substr(pos, next_space - pos));
            pos = next_space + 1;
            int v = stoi(command.substr(pos));
            lock_guard<mutex> lock(listOfTheGraph); // Lock the list .
            aa.Newedge(u,v);
            send(client_fd, "Edge added\n", 11, 0);

        } else if (command.substr(0, 10) == "Removeedge") {
            cout << "Processing Removeedge command" << endl;
            size_t pos = 11;
            size_t next_space = command.find(" ", pos);
            int u = stoi(command.substr(pos, next_space - pos));
            pos = next_space + 1;
            int v = stoi(command.substr(pos));
            lock_guard<mutex> lock(listOfTheGraph); // Lock the list .
            aa.Removeedge(u,v);
            send(client_fd, "Edge removed\n", 13, 0);

        } else {
            cout << "Unknown command: " << command << endl;
            send(client_fd, "Unknown command\n", 16, 0);
        }
    } catch (const exception& e) {
        cerr << "Error handling command: " << e.what() << endl;
        send(client_fd, "Error processing command\n", 25, 0);
    }
}







// Get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa){
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

// Return a listening socket
int get_listener_socket(){
    int listener;     // Listening socket descriptor
    int yes=1;        // For setsockopt() SO_REUSEADDR, below
    int rv;

    struct addrinfo hints, *ai, *p;

    // Get us a socket and bind it
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;  // we dont have a preference to ipv4 or ipv6
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    if ((rv = getaddrinfo(NULL, PORT, &hints, &ai)) != 0) {
        fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
        exit(1);
    }

    for(p = ai; p != NULL; p = p->ai_next) {
        listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (listener < 0) {
            continue;
        }

        // Lose the pesky "address already in use" error message
        setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

        if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) {
            close(listener);
            continue;
        }

        break;
    }

    freeaddrinfo(ai); // All done with this

    // If we got here, it means we didn't get bound
    if (p == NULL) {
        return -1;
    }

    // Listen
    if (listen(listener, 10) == -1) {
        return -1;
    }

    return listener;
}

//Add a new file descriptor to the set
void add_to_pfds(vector<pollfd>& pfds, int newfd) {
    pfds.push_back({newfd, POLLIN, 0});
}

// Remove an index from the set
void del_from_pfds(vector<pollfd>& pfds, int i) {
    pfds.erase(pfds.begin() + i);
}

/*
After the connection between the client and the server,
we will want to activate the server so that each client will be handled in an individual independent manner
and we will be able to manipulate how much the client
*/
void clientHandler(int client_fd,Graph &aa) {
    char buf[256];
    while (true) {
        int nbytes = recv(client_fd, buf, sizeof(buf), 0);
        if (nbytes <= 0) {
            if (nbytes == 0) {
                cout << "Client " << client_fd << " disconnected" << endl;
            } else {
                perror("recv");
            }
            close(client_fd);
            break;
        } else {
            string command(buf, nbytes);
            HandleCommand(command, client_fd,ref(aa));
        }
    }
}
void* proactor_f(int client_fd) {
    char buf[256];
    while (true) {
        int nbytes = recv(client_fd, buf, sizeof(buf), 0);
        if (nbytes <= 0) {
            if (nbytes == 0) {
                cout << "Client " << client_fd << " disconnected" << endl;
            } else {
                perror("recv");
            }
            close(client_fd);
            break;
        } else {
            string command(buf, nbytes);
            Graph a=Graph (0);
            HandleCommand(command, client_fd,a);
        }
    }
    return nullptr;
}



int main() {
    int listener;     // Listening socket descriptor
    int newfd;        // Newly accept()ed socket descriptor

    struct sockaddr_storage remoteaddr{}; // Client address
    socklen_t addrlen;

    char buf[256];    // Buffer for client data
    char remoteIP[INET6_ADDRSTRLEN];

    // Set up and get a listening socket
    listener = get_listener_socket();
    if (listener == -1) {
        cerr << "error getting listening socket" << endl;
        exit(1);
    }
    else(cout<<"listening socket succeeded"<<endl);

    //Description of files if we want to use them again
    fd_set firset;
    fd_set read;
    int fd;

    map<int, ClientInfo> clients;

    Graph a= Graph(0);

    FD_ZERO(&firset);
    FD_ZERO(&read);
    FD_SET(listener, &firset);
    fd = listener;
    cout << "Waiting for connections to the sokcet..." << endl;

    while (true) {
        read = firset;
        if (select(fd + 1, &read, NULL, NULL, NULL) == -1) {
            cout << "Select error" << endl;
            return 1;
        }

        for (int i = 0; i <= fd; ++i) {
            if (FD_ISSET(i, &read)) {
                if (i == listener) {
                    struct sockaddr_storage address;
                    socklen_t addrlen = sizeof address;
                    int newfd = accept(listener, (struct sockaddr *)&address, &addrlen);
                    if (newfd == -1) {
                        cerr << "Accept error" << endl;
                    } else {
                        FD_SET(newfd, &firset);
                        if (newfd > fd) {
                            fd = newfd;
                        }
                        cout << "New connection from " << inet_ntoa(((struct sockaddr_in *)&address)->sin_addr) << " on socket " << newfd << endl;

                        // Start proactor
                        pthread_t tid = startProactor(newfd, (proactor_f));
                        if (tid == 0) {
                            cerr << "Failed to start proactor thread" << endl;
                        } else {
                            clients[newfd] = {newfd, tid};
                        }
                    }
                } else {
                    char buf[256];
                    int byte_r = recv(i, buf, sizeof buf, 0);
                    if (byte_r <= 0) {
                        if (byte_r == 0) {

                            cout << "Socket " << i << " disconnected" << endl;
                        } else {
                            cerr << " error socket " << i << endl;
                        }
                        close(i);
                        FD_CLR(i, &firset);

                        // Find and stop the corresponding proactor thread
                        auto it = clients.find(i);
                        if (it != clients.end()) {
                            stopProactor(it->second.thread_id);
                            clients.erase(it); // Erase client info from map
                        }

                    } else {
                        buf[byte_r] = '\0';
                        string command(buf);
                        HandleCommand(command, i,a);
                    }
                  }
                }
            }
        }

        for (const auto& client : clients) {
            stopProactor(client.second.thread_id);
        }
        return 0;

}