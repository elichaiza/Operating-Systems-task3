
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
#include "Matrix.hpp"


Graph::Graph(int n) {
    this->n = n;
    adj = vector<vector<int>>(n);
}

void Graph::addEdge(int v, int w) {
    adj[v - 1].push_back(w - 1); // הוספת קשת מ-v ל-w (מינוס 1 כדי להתאים לאינדקסים של 0)
}

void Graph::fillOrder(int v, vector<bool>& visited, stack<int>& Stack) {
    visited[v] = true;

    for (int i : adj[v])
        if (!visited[i])
            fillOrder(i, visited, Stack);

    Stack.push(v);
}

void Graph::DFSUtil(int v, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v + 1); // להחזיר לקודקודים את האינדקס המקורי

    for (int i : adj[v])
        if (!visited[i])
            DFSUtil(i, visited, component);
}

Graph Graph::getTranspose() {
    Graph g(n);
    for (int v = 0; v < n; v++)
        for (int i : adj[v])
            g.adj[i].push_back(v);
    return g;
}

void Graph::printSCCs() {
    stack<int> Stack;

    vector<bool> visited(n, false);

    for (int i = 0; i < n; i++)
        if (!visited[i])
            fillOrder(i, visited, Stack);

    Graph gr = getTranspose();

    fill(visited.begin(), visited.end(), false);

    while (!Stack.empty()) {
        int v = Stack.top();
        Stack.pop();

        if (!visited[v]) {
            vector<int> component;
            gr.DFSUtil(v, visited, component);

            sort(component.begin(), component.end());
            for (int i : component)
                cout << i << " ";
            cout << endl;
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;

    Graph g(n);

    for (int i = 0; i < m; i++) {
        int v, w;
        cin >> v >> w;
        g.addEdge(v, w);
    }

    g.printSCCs();

    return 0;
}