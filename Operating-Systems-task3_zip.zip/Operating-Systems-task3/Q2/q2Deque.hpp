
//elichaiza@gmail.com
//id:318691821

#ifndef Q2DEQUE_H
#define Q2DEQUE_H
#include <iostream>
#include <vector>
#include <stack>
#include <deque>

using namespace std;

class Graph {
    int V; // מספר הקודקודים
    deque<int> *adj; // רשימת שכנות

    void fillOrder(int v, vector<bool> &visited, stack<int> &Stack);
    void DFSUtil(int v, vector<bool> &visited);

public:
    Graph(int V);
    void addEdge(int v, int w);
    void printSCCs();
    Graph getTranspose();
};

#endif //Q2DEQUE_H
