

#ifndef MATRIX_H
#define MATRIX_H
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

class Graph {
    int n; // מספר הקודקודים
    vector<vector<int>> adj; // מטריצת שכנויות

    void fillOrder(int v, vector<bool>& visited, stack<int>& Stack);
    void DFSUtil(int v, vector<bool>& visited, vector<int>& component);

public:
    Graph(int n); // בונה
    void addEdge(int v, int w); // הוספת קשת לגרף
    void printSCCs(); // הדפסת רכיבי הקשירות החזקה
    Graph getTranspose(); // החזרת גרף המהפך
};

#endif //MATRIX_H
