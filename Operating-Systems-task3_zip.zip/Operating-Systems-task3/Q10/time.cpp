#include <iostream>
#include <thread>
#include <mutex>

pthread_cond_t condition_var = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex_lock = PTHREAD_MUTEX_INITIALIZER;
bool trigger = false;

void* thread_func(void* arg) {
    while (true) {
        pthread_mutex_lock(&mutex_lock);
        while (!trigger) {
            pthread_cond_wait(&condition_var, &mutex_lock);
        }
        // Reset trigger and unlock mutex before printing
        trigger = false;
        pthread_mutex_unlock(&mutex_lock);
        std::cout << "Thread activated" << std::endl;
    }
    return NULL;
}

int main() {
    pthread_t worker_thread;
    pthread_create(&worker_thread, NULL, thread_func, NULL);
    while (true) {
        std::string command;
        std::cin >> command;
        if (command == "activate") {
            pthread_mutex_lock(&mutex_lock);
            trigger = true;
            pthread_cond_signal(&condition_var);
            pthread_mutex_unlock(&mutex_lock);
        }
    }
    return 0;
}
